module DepInternal
  ( depInternalValue
  ) where

depInternalValue :: Int
depInternalValue = 41
