module Dep
  ( depValue
  ) where

import DepInternal ( depInternalValue )

depValue :: Int
depValue = depInternalValue + 1
